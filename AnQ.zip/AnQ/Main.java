package com.example.dennissakyiama.sakyiama9602;

public class Main {
    

    public static void main(String[] args) {

    }
}